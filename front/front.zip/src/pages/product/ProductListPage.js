import React from 'react'
import ListComponent from '../../components/products/ListComponent'

const ProductListPage = () => {
  return (
    <div><ListComponent /></div>
  )
}

export default ProductListPage