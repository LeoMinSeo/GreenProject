import React from "react";
import ReadComponent from "../../components/products/ReadComponent";

const ProductReadPage = () => {
  return <ReadComponent />;
};

export default ProductReadPage;
