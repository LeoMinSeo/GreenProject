import React from "react";
import MainComponent from "../components/MainComponent";

const MainPage = () => {
  return <MainComponent />;
};

export default MainPage;
