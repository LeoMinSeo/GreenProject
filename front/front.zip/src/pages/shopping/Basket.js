import React from "react";
import BasketComponent from "../../components/shopping/BasketComponent";

const Basket = () => {
  return (
    <div>
      <BasketComponent />
    </div>
  );
};

export default Basket;
