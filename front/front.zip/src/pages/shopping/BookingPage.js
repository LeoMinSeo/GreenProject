import React from "react";
import BookingPaymentComponent from "../../components/shopping/BookingPaymentComponent";

const BookingPage = () => {
  return <BookingPaymentComponent />;
};

export default BookingPage;
