import React from "react";
import NonMemberBasketComponent from "../../components/shopping/NonMemberBasketComponent";
const NonMemberBasketPage = () => {
  return <NonMemberBasketComponent />;
};

export default NonMemberBasketPage;
