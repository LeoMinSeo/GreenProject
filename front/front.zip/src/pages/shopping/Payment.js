import React from "react";
import PaymentComponent from "../../components/shopping/PaymentComponent";

const Payment = () => {
  return (
    <div>
      <PaymentComponent />
    </div>
  );
};

export default Payment;
