import React from "react";
import ReadComponent from "../../components/reservation/ReadComponent";


const ReservationReadPage = () => {
 
  return <ReadComponent  />;
};

export default ReservationReadPage;
