import React from "react";
import AdminMainComponent from "../../components/admin/AdminMainComponent";

const AdminMainPage = () => {
  return (
    <div>
      <AdminMainComponent />
    </div>
  );
};

export default AdminMainPage;
