import React from "react";
import MainComponent from "../../components/admin/MainComponent";

const AdminMainPage = () => {
  return (
    <div>
      <MainComponent />
    </div>
  );
};

export default AdminMainPage;
