import React from "react";
import AddoneComponent from "../../components/admin/AddoneComponent";
const AdminAddonePage = () => {
  return (
    <div>
      <AddoneComponent />
    </div>
  );
};

export default AdminAddonePage;
