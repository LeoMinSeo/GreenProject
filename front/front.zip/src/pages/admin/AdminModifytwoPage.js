import React from "react";
import ModifytwoComponent from "../../components/admin/ModifytwoComponent"

const AdminModifytwoPage = () => {
  return (
    <div>
      <ModifytwoComponent />
    </div>
  );
};

export default AdminModifytwoPage;
