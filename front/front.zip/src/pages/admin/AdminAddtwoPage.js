import React from "react";
import AddtwoComponent from "../../components/admin/AddtwoComponent";

const AdminAddtwoPage = () => {
  return (
    <div>
      <AddtwoComponent />
    </div>
  );
};

export default AdminAddtwoPage;
