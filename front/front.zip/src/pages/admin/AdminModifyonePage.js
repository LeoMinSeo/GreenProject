import React from "react";
import ModifyoneComponent from "../../components/admin/ModifyoneComponent";

const AdminModifyonePage = () => {
  return (
    <div>
      <ModifyoneComponent />
    </div>
  );
};

export default AdminModifyonePage;
