import React from "react";
import Signup from "../../components/member/SignupComponent";

const SignupPage = () => {
  return (
    <div>
      <Signup />
    </div>
  );
};

export default SignupPage;
