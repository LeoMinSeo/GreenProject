import axios from "axios";

const host = "http://localhost:8089/concert";

export const getList = async () => {
  const res = await axios.get(`${host}/list`);
  return res.data;
};
