import React from "react";

const LogoutComponent = () => {
  return <div className="mt-24">LogoutComponent</div>;
};

export default LogoutComponent;
