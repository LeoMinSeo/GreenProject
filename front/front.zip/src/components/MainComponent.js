import React, { useState, useEffect } from "react";
import MainMenubar from "./menu/MainMenubar";

const sections = [
  { id: "firstPage", text: "첫번째", imgUrl: "/images/main2.jpg" },
];

const MainComponent = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [fadeIn, setFadeIn] = useState(false);

  useEffect(() => {
    // 컴포넌트 마운트 후 애니메이션 시작
    setTimeout(() => {
      setFadeIn(true);
    }, 300);
  }, []);

  const showSection = (index) => {
    if (index >= 0 && index < sections.length) {
      setCurrentIndex(index);
    }
  };

  const handleScroll = (event) => {
    if (event.deltaY > 0) {
      showSection(currentIndex + 1);
    } else {
      showSection(currentIndex - 1);
    }
  };

  return (
    <div
      className="relative w-full h-screen overflow-hidden"
      onWheel={handleScroll}
    >
      <MainMenubar currentIndex={currentIndex} />
      {/* 페이지 섹션 */}
      <div className="relative w-full h-full">
        {sections.map((section, index) => (
          <div
            key={section.id}
            className="absolute top-0 left-0 w-full h-screen flex items-center justify-center text-3xl font-bold transition-transform duration-700 ease-in-out"
            style={{
              backgroundImage: `url(${section.imgUrl})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
              transform: `translateY(${(index - currentIndex) * 100}%)`,
            }}
          >
            {index === 0 ? (
              <div
                className={`absolute inset-0 flex flex-col items-center justify-center text-center transition-opacity duration-1000 ease-in-out ${
                  fadeIn ? "opacity-100" : "opacity-0"
                }`}
              >
                <div className="relative flex flex-col items-center py-8">
                  {/* 로고와 텍스트를 포함하는 컨테이너 */}
                  <div className="relative">
                    {/* 왼쪽 상단에 대각선으로 배치된 로고 */}
                    <div
                      className="absolute -top-24 -left-24 w-40 h-40 z-10"
                      style={{
                        transform: "rotate(-15deg)",
                        animation: "floatInSpace 6s ease-in-out infinite",
                      }}
                    >
                      <img
                        src="images/1stpageLogo.png"
                        className="w-full h-full object-contain"
                      />
                    </div>

                    {/* 메인 텍스트 */}
                    <h1
                      className="text-6xl font-extrabold tracking-wider relative z-10"
                      style={{
                        color: "#FF9E40",
                        textShadow: "0 2px 10px rgba(0, 0, 0, 0.4)",
                        letterSpacing: "0.05em",
                      }}
                    >
                      AudiMew
                    </h1>
                  </div>

                  {/* 오디오 웨이브 효과 */}
                  <div className="flex justify-center items-end h-2 z-0 mt-4">
                    {[...Array(14)].map((_, i) => (
                      <div
                        key={i}
                        className="mx-1 rounded-t-full bg-orange-400"
                        style={{
                          width: "4px",
                          height: `${8 + Math.random() * 8}px`,
                          animation: `soundWave ${
                            0.5 + Math.random() * 0.5
                          }s ease-in-out infinite alternate`,
                          animationDelay: `${i * 0.05}s`,
                          opacity: 0.8,
                        }}
                      />
                    ))}
                  </div>

                  {/* 애니메이션 스타일 */}
                  <style jsx>{`
                    @keyframes floatInSpace {
                      0% {
                        transform: rotate(-15deg) translate(0, 0);
                      }
                      25% {
                        transform: rotate(-12deg) translate(5px, -5px);
                      }
                      50% {
                        transform: rotate(-18deg) translate(0, 8px);
                      }
                      75% {
                        transform: rotate(-13deg) translate(-5px, 3px);
                      }
                      100% {
                        transform: rotate(-15deg) translate(0, 0);
                      }
                    }
                  `}</style>
                </div>

                <p
                  className="mt-6 text-lg leading-relaxed max-w-2xl"
                  style={{
                    color: "#f8f8f8",
                    textShadow: "1px 1px 6px rgba(0, 0, 0, 0.7)",
                    lineHeight: "1.8",
                    animation: "fadeInUp 1.2s ease-out",
                  }}
                >
                  <span style={{ color: "#FFB74D" }}>최고의 사운드</span>를 위한
                  헤드셋, 스피커 프리미엄 오디오 기기를 제공하는 동시에
                  <br />
                  콘서트, 오케스트라, 뮤지컬 등{" "}
                  <span style={{ color: "#FFB74D" }}>다양한 공연 티켓</span>을
                  예약할 수 있는
                  <br />
                  기존과 다른 새로운 패러다임의 음악 문화 플랫폼입니다.
                </p>

                <p
                  className="mt-6 text-xl font-bold max-w-2xl"
                  style={{
                    color: "#f8f8f8",
                    textShadow: "1px 1px 6px rgba(0, 0, 0, 0.7)",
                    animation: "fadeInUp 1.5s ease-out",
                  }}
                >
                  듣고, 경험하고, 소유하는 새로운 방식
                  <br />
                  <span
                    style={{
                      color: "#FF9E40",
                      textShadow: "0 0 10px rgba(255, 158, 64, 0.6)",
                      animation: "glow 1.5s infinite alternate",
                    }}
                  >
                    AudiMew
                  </span>
                  에서 시작하세요.
                </p>
              </div>
            ) : (
              <span className="relative z-10 text-4xl font-bold">
                {section.text}
              </span>
            )}
          </div>
        ))}
      </div>
      {/* 메인 이름 스타일 추가 */}
      <style jsx>{`
        @keyframes soundWave {
          0% {
            height: 4px;
          }
          100% {
            height: 16px;
          }
        }
      `}</style>
      {/* 애니메이션 스타일 */}
      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes glow {
          from {
            text-shadow: 0 0 5px rgba(255, 158, 64, 0.5),
              0 0 10px rgba(255, 158, 64, 0.3);
          }
          to {
            text-shadow: 0 0 10px rgba(255, 158, 64, 0.8),
              0 0 20px rgba(255, 158, 64, 0.5);
          }
        }
      `}</style>
    </div>
  );
};

export default MainComponent;
