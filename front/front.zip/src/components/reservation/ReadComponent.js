import React from "react";
import SubMenubar from "../menu/SubMenubar";

const ReadComponent = () => {
  return (
    <div className="border-2 border-sky-200 p-4">
      <SubMenubar />
      <div>레저베이션 리드 페이지</div>
    </div>
  );
};

export default ReadComponent;
