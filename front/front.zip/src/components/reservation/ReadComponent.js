import React from "react";
import MainMenubar from "../menu/MainMenubar";

const ReadComponent = () => {
  return (
    <div className="border-2 border-sky-200 p-4">
      <MainMenubar />
      <div>레저베이션 리드 페이지</div>
    </div>
  );
};

export default ReadComponent;
