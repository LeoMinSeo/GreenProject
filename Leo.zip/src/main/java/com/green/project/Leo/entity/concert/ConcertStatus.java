package com.green.project.Leo.entity.concert;

public enum ConcertStatus {
    AVAILABLE,
    SOLD_OUT
}
