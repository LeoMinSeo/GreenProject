package com.green.project.Leo.entity.concert;

public enum OrderStatusforConcert {
    CANCLE,
    RESERVATION
}
