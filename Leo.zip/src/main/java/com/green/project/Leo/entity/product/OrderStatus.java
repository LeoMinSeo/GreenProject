package com.green.project.Leo.entity.product;

public enum OrderStatus {
    PAY_COMPLETED,
    SHIPPING,
    DELIVERED

}
