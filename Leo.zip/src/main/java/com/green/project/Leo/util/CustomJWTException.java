package com.green.project.Leo.util;




public class CustomJWTException extends RuntimeException{

    public CustomJWTException(String msg){
        super(msg);


    }


}
