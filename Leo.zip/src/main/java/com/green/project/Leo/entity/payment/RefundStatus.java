package com.green.project.Leo.entity.payment;

public enum RefundStatus {
    WAITING,
    COMPLETE,
    REJECTED
}
