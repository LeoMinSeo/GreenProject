package com.green.project.Leo.repository.concert;

import com.green.project.Leo.entity.concert.ConcertReview;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConcertReviewRepository extends JpaRepository<ConcertReview,Long> {
}
