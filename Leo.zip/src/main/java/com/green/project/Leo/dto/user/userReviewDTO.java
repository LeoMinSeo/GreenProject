package com.green.project.Leo.dto.user;

public class userReviewDTO {
    private String pname;
}
