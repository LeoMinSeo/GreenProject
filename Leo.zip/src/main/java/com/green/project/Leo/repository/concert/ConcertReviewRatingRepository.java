package com.green.project.Leo.repository.concert;

import com.green.project.Leo.entity.concert.ConcertReviewRating;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConcertReviewRatingRepository extends JpaRepository<ConcertReviewRating,Long> {

}
