package com.green.project.Leo.entity.user;

public enum UserRole {
    USER,ADMIN
}
