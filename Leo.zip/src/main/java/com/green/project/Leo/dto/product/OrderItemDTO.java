package com.green.project.Leo.dto.product;

import com.green.project.Leo.entity.product.Product;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OrderItemDTO {
    private Long pNo;
    private int numOfItem;
}
