package com.green.project.Leo.repository.concert;

import com.green.project.Leo.entity.concert.ConcertImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ConcertImageRepository extends JpaRepository<ConcertImage,Long> {
}
